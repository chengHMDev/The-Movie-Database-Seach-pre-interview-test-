<?php
//$username = $_POST['query'];
define("key", "561e4768f398928a37cd0b8a56320845");
global $resultLog;

//get configuration from TMDB API and pass the configuration info to runSearch()
function getConfig() {
	session_start();
	$baseURL = "https://api.themoviedb.org/3/";
	$url = $baseURL."configuration?api_key=".key;
	$json = file_get_contents($url);
	$result = json_decode($json, true);
	$configData = $result["images"];
	$baseImageURL = $configData["secure_base_url"];
	runSearch($baseURL,$configData,$baseImageURL);
}

//run the search for a specific keyword and pass the return result into formatResult()
function runSearch($baseURL,$configData,$baseImageURL) {
	$query = $_POST['query'];
	$query = urlencode($query);
	//for now only runs the first page of the result
	$url = $baseURL."search/movie?api_key=".key.'&query='.$query;
	$json = file_get_contents($url);
	$result = json_decode($json, true);
	$resultsets = $result["results"];
	formatResult($resultsets,$configData,$baseImageURL);
}

//this fuction extract the needed parameter from the result returned from the API
function formatResult($resultsets,$configData,$baseImageURL){
		$searchData = [];
		for ($i = 0; $i < count($resultsets); $i++) {
		//For now only retrive result with a poster path
		if($resultsets[$i]["poster_path"]!=null){
			$imgURL = $baseImageURL.$configData["poster_sizes"][4].$resultsets[$i]["poster_path"];
			
			//get the blob data from the URL 
			//Need improvement in future version due to performance issue cause by file_get_contents()
			$image = file_get_contents($imgURL);
			
			//empty varable for description, language, release_date, rating
			$description = "";
			$language = "";
			$release_date = "";  
			$rating = 0;
			
			//check if overview exist if yes take the original overview if not then "NA"
			if($resultsets[$i]["overview"]!=null){
				$description = $resultsets[$i]["overview"];
			}else{
				$description = "";
			}
			
			//check if language exist if yes take the original language if not then "NA"
			//improvement can be done here to convert for form such as en/ja to English/Japanese
			if($resultsets[$i]["original_language"]!=null){
				$language = $resultsets[$i]["original_language"];
			}else{
				$language = "NA";
			}

			//check if release date exist if yes take the release date if not then "NA"
			if($resultsets[$i]["release_date"]!=null){
				$release_date = date("Y-m-d",strtotime($resultsets[$i]["release_date"]));
			}else{
				$release_date = null;
			}
			
			//check if vote average exist if yes take the ratings if not then 0.0
			if($resultsets[$i]["vote_average"]!=null){
				$rating = $resultsets[$i]["vote_average"];
			}else{
				$rating = null;
			}
			
			//combine this to a array for all the data
			$resultInstance = [];
			array_push($resultInstance,$resultsets[$i]["id"],$resultsets[$i]["original_title"],$release_date,$language,$rating,$description,$image,$imgURL);
			array_push($searchData,$resultInstance);
		}
		
		
	}
	//set this to a session 
	$_SESSION['searchData'] = $searchData;
	//save the data
	saveRetrivedData();
}
function saveRetrivedData(){
	//require the database.con.php and save the session into the database
	require_once('database.con.php');
	for($i=0;$i<count($_SESSION['searchData']);$i++){
		saveData($_SESSION['searchData'][$i][0],$_SESSION['searchData'][$i][1],$_SESSION['searchData'][$i][2],$_SESSION['searchData'][$i][3],$_SESSION['searchData'][$i][4],$_SESSION['searchData'][$i][5],$_SESSION['searchData'][$i][6],$_SESSION['searchData'][$i][7]);
	}
	//redirect the page back to index.php after operation has been completed
	header("location:index.php");
}




getConfig();
?>