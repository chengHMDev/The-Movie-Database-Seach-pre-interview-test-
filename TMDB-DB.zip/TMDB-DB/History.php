<!DOCTYPE html>

<html>
<head>
  <?php 
	session_start();
  ?>
  <meta charset="UTF-8">
  <script src="key.js"></script>
  <script src="FileSaver.js"></script>
  <title>Movie Search</title>
  <link rel="stylesheet" href="style.css?<?php echo time(); ?>" media="screen" type="text/css" />

</head>

<body>

  <div>
  	<div class="header animated fadder">
		<div class="logo-div">
			<img src="logo.png" class="logo">
		</div>
		<div class="text-div">
			<h1>Movie Search</h1>
		</div>
	</div>
  	<div class="content-area"> 
		<a href="index.php" class="back">← Back To Search</a>
  	</div>
  </div>
  <div id="result" class="result">
    <!--<script src="executeSearch.js?<?php echo time()?>"></script>-->
	<?php
	//require the database.con.php file
	require_once('database.con.php');
	
	//get all the movie stored in the database
	$result = getAllMovie();
	$historyData = [];
	
	//loop through all the record in the session
	//if there is data returned from the database display all the results 
	$resultExist = false;
	foreach($result as $mov){
		$resultInstance = [];
		$movieID = $mov[0];
		$title = $mov[1];
		$dateAired = $mov[2];
		$language = $mov[3];
		$rating = $mov[4]*10;
		$description = $mov[5];
		$posterImg = $mov[6];
		$views = $mov[7];
		array_push($resultInstance,$movieID,$title,$dateAired,$language,$rating,$description,$posterImg,$views);
		array_push($historyData,$resultInstance);
		$resultExist = true;
	}
	
	//If data is returned from the database
	if($resultExist == true){
		for($i=0;$i<count($historyData);$i++){
			echo '<table class="movie-table">';
				echo '<tr>';
					//Titile
					echo '<th colspan="2">';
						echo $historyData[$i][1];
					echo '</th>';
				echo '</tr>';
				echo '<tr>';
					//Image
					echo '<td class="poster-col">';
						echo '<img src="data:image/jpeg;base64,'.base64_encode($historyData[$i][6]).'" class="poster" id="fdsa" name="dadsg">';
					echo '</td>';
					echo '<td>';
						//view count
						echo '<b>Number of time visited: </b>'.$historyData[$i][7].'<br>';
						//Ratings
						echo '<b>Rating: </b>'.$historyData[$i][4].'%';
						echo '<br><br>';
						//Language
						echo '<b>Language: </b>'.$historyData[$i][3];
						echo '<br><br>';
						//Date Aired
						echo '<b>Date Aired: </b>'.$historyData[$i][2];
						echo '<br><br>';
						//Description
						echo '<b>Description: </b>'.$historyData[$i][5];
					echo '</td>';
				echo '</tr>';
			echo '</table>';
		}
	}
	?>
	
	<script>
		saveButton = document.getElementById('save');
		saveButton.addEventListener('click', e => {
			window.location = 'History.php';
		})
	</script>
  </div>


</body>
</html>