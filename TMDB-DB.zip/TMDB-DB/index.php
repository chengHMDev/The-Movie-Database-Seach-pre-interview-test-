<!DOCTYPE html>

<html>
<head>
  <?php 
	session_start();
  ?>
  <meta charset="UTF-8">
  <script src="key.js"></script>
  <script src="FileSaver.js"></script>
  <title>Movie Search</title>
  <link rel="stylesheet" href="style.css?<?php echo time(); ?>" media="screen" type="text/css" />

</head>

<body>

  <div>
  	<div class="header animated fadder">
		<div class="logo-div">
			<img src="logo.png" class="logo">
		</div>
		<div class="text-div">
			<h1>Movie Search</h1>
		</div>
	</div>
  	<div class="content-area"> 
		<form id="form" method="post" action="executeSearch.php">
			<input type="text" id="query" name="query" class="textfield1" placeholder="Enter Movie Title">
			<input type="submit" name="search" class="button" value="search">
			<input type="button" id="history" name="history" class="button" value="History" onclick="viewHistory()">
  		</form>
		
  	</div>
  </div>
  <div id="result" class="result">
	<?php
	//detect if a session already exist if yes set all the parameter
	$sessionExist = false;
	if(isset($_SESSION['searchData'])){
		$sessionExist = true;
		//debig line
		echo "<script>console.log('data exist');</script>";
	}
	if($sessionExist == true){
		//loop through all the record in the session
		for($i=0;$i<count($_SESSION['searchData']);$i++){
			echo '<table class="movie-table">';
				echo '<tr>';
					//Title
					echo '<th colspan="2">';
						echo $_SESSION['searchData'][$i][1];
					echo '</th>';
				echo '</tr>';
				echo '<tr>';
					//image
					echo '<td class="poster-col">';
						echo '<img src="data:image/jpeg;base64,'.base64_encode($_SESSION['searchData'][$i][6]).'" class="poster" id="fdsa" name="dadsg">';
					echo '</td>';
					//rating, language, date aired, description
					echo '<td>';
						echo '<b>Rating: </b>'.($_SESSION['searchData'][$i][4]*10).'%';
						echo '<br><br>';
						echo '<b>Language: </b>'.$_SESSION['searchData'][$i][3];
						echo '<br><br>';
						echo '<b>Date Aired: </b>'.$_SESSION['searchData'][$i][2];
						echo '<br><br>';
						echo '<b>Description: </b>'.$_SESSION['searchData'][$i][5];
					echo '</td>';
				echo '</tr>';
			echo '</table>';
		}
	}
	?>
	
	<script>
		//redirect to history page when the history button is clicked
		saveButton = document.getElementById('history');
		saveButton.addEventListener('click', e => {
			window.location.href = 'History.php';
		})
	</script>
  </div>


</body>
</html>