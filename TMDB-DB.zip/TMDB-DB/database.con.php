<?php
//This function establish the connection to the database
function setConnectionInfo(){
	$connString = 'mysql:host=localhost;dbname=moviedb';
	$user = 'root';
	$password = '';
	
	$pdo = new PDO($connString,$user,$password);
	$pdo->setAttribute(PDO::ATTR_ERRMODE,PDO::ERRMODE_EXCEPTION);
	return $pdo;
}

//This function run the query
function runQuery($pdo,$sql){
	$statement = null;
	$statement = $pdo->query($sql);
	if(!$statement){ throw new PDOException;}
	return $statement;	
}

//This fuction save a new movie data into the database at the sametime create a history log
function saveData($movieID,$title,$dateAired,$language,$ratings,$description,$posterImg,$URL){
		//echo "<br>";
		//print_r($title);
		//echo "<br>";
	$pdo = setConnectionInfo();
	$sampleDate = date('Y-m-d', strtotime('1999-12-31'));
	
	$result = getMovieByID($movieID);
	
	//replace ' with ''
	$title = str_replace("'","''",$title);
	$description = str_replace("'","''",$description);
	
	//create a bool to track movie already exist or not
	$found = false;
	
	foreach($result as $mov){
		//debug line
		echo "<script>console.log('".$mov[0]."');</script>";
		$found = true;
	}
	
	if($found==true){
		//echo "<br>";
		//print_r($title);
		//echo "<br>";
		incTimesVisited($movieID);
	}else{
		//echo "<br>";
		//print_r("JK: ".$title);
		//echo "<br>";
		addMovie($movieID,$title,$dateAired,$language,$ratings,$description,$posterImg,$URL);
		
	}
	$result = null;

	
}

//get a movie using the ID of the movie
function getMovieByID($MovieID){
	$pdo = setConnectionInfo();
	$statement = runQuery($pdo,"SELECT * FROM MOVIE WHERE movieId = '".$MovieID."'");
	return $statement;
}

//get all the movie in the database
function getAllMovie(){
	$pdo = setConnectionInfo();
	$statement = runQuery($pdo,"SELECT M.movieId, M.title, M.dateAired, M.movlanguage, M.ratings, M.description, M.posterImg, H.timesVisited FROM Movie AS M,History AS H WHERE M.movieID = H.movieID");
	return $statement;
}

//add a movie into the database
function addMovie($movieID,$title,$dateAired,$language,$ratings,$description,$posterImg,$URL){
	$pdo = setConnectionInfo();
	$statement = runQuery($pdo,"INSERT INTO MOVIE (movieId,title,dateAired,movlanguage,ratings,description,posterImg,posterURL ) VALUES ('".$movieID."','".$title."', '".$dateAired."', '".$language."', '".$ratings."','".$description."', '".addslashes($posterImg)."', '".$URL."')");
	addHistory($movieID);
}

//make a new history record for a particular movie ID
function addHistory($movieID){
	$pdo = setConnectionInfo();
	$statement = runQuery($pdo,"INSERT INTO HISTORY (movieId,timesVisited) VALUES (".$movieID.",1)");
}

//increase the view count for a particular movie using movie ID
function incTimesVisited($movieID){
	//print_r($movieID);
	$pdo = setConnectionInfo();
	$statement = runQuery($pdo,"UPDATE HISTORY SET timesVisited = timesVisited + 1 WHERE movieId = ".$movieID);
}


?>